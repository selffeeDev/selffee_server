module.exports = {
    OK : 200,
    BAD_REQUEST : 400,
    FAIL : 500
}